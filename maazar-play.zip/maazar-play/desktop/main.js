const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');

// Toca o canal assim que é escolhido, sem esperar clique extra.
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 780,
    minWidth: 420,
    minHeight: 500,
    backgroundColor: '#020a33',
    title: 'Maazar Play',
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      // Como app, pode baixar listas e canais de qualquer servidor
      // (o navegador comum bloqueia vários deles).
      webSecurity: false,
      contextIsolation: true
    }
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, 'web', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file:')) { e.preventDefault(); shell.openExternal(url); }
  });
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
