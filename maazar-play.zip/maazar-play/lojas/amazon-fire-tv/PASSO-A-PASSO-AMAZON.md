# Publicar o Maazar Play na Amazon (Fire TV)

Tudo o que você precisa está nesta pasta (`lojas/amazon-fire-tv`) e no arquivo **`Maazar-Play.apk`** da página **Releases** do GitHub (use a versão mais recente).

> **Antes de começar, confira o site:** abra `https://contatocapclean-hue.github.io/maazar-play/privacidade.html` no navegador. Se aparecer a política de privacidade do Maazar Play, está tudo certo. Se der erro 404, ative **Settings › Pages › Source: GitHub Actions** no repositório e rode a montagem de novo (aba Actions › Gerar aplicativos › Run workflow).

---

## 1. Criar a conta (grátis)
1. Acesse **developer.amazon.com** › **Sign in** › crie uma conta de desenvolvedor. Pode usar o e-mail `maazarserv@gmail.com`.
2. Preencha o perfil: nome do desenvolvedor **Maazar Play**, e-mail, país **Brasil** e telefone.
3. Aceite o contrato de distribuição. Como o app é gratuito, normalmente não é preciso cadastrar dados bancários. Se o console pedir a entrevista de impostos, responda como pessoa física brasileira.

## 2. Criar o app
**Apps & Services › My Apps › Add New App › Android**.

| Campo | O que colocar |
|---|---|
| App title | `Maazar Play` |
| App SKU | `maazar-play-firetv` |
| App category | Categoria de vídeo da lista (*Movies & TV* ou *Video*) |
| Customer support email | `maazarserv@gmail.com` |
| Customer support website | `https://contatocapclean-hue.github.io/maazar-play` |

## 3. Availability & Pricing
- **Availability:** todos os países (ou só **Brasil**, se preferir começar menor).
- **Pricing:** **Free** (gratuito).
- **Publishing date:** deixe em branco para publicar assim que for aprovado.

## 4. Description (idioma: Português do Brasil)

**Short description** (até 1.200 caracteres):
```
Reprodutor de vídeo para as suas próprias listas: adicione o endereço de um servidor com usuário e senha ou o endereço de uma lista M3U e assista com uma tela feita para o controle remoto da Fire TV. O Maazar Play não vende nem fornece conteúdo.
```

**Long description** (até 4.000 caracteres):
```
O Maazar Play é um reprodutor de vídeo para as listas que você já possui.

Adicione a sua lista (o endereço de um servidor com usuário e senha, ou o endereço de uma lista M3U) e assista com uma interface pensada para a TV e o controle remoto.

Na tela inicial você encontra destaques, filmes, séries e canais organizados em fileiras. As categorias ficam sempre à mão, com busca e uma lista de favoritos. O app lembra onde você parou e passa para o próximo episódio sozinho.

Sem cadastro: os dados que você digita ficam somente no seu aparelho.

IMPORTANTE: o Maazar Play NÃO vende, não fornece e não indica canais, filmes, séries, listas ou assinaturas. O app não contém nenhum conteúdo. Para usar, você precisa ter uma lista própria, de uma fonte que tenha o direito de distribuí-la. As imagens são ilustrativas.

Política de privacidade: https://contatocapclean-hue.github.io/maazar-play/privacidade.html
Termos de uso: https://contatocapclean-hue.github.io/maazar-play/termos.html
```

**Product feature bullets** (um por linha):
```
Reprodutor para as suas próprias listas (servidor com usuário e senha, ou M3U)
Feito para o controle remoto da Fire TV
Filmes, séries e canais organizados em fileiras
Todas as categorias à mão, busca e favoritos
Continua de onde você parou
Próximo episódio automático
Troca de canal com CH+/CH− e números do controle
Ajuste de margem para TVs que cortam as bordas
Sem cadastro: seus dados ficam só no aparelho
Não contém nem fornece conteúdo
```

**Keywords:**
```
player, reprodutor, video, m3u, lista, playlist, tv, filmes, series
```

## 5. Images & Multimedia
Na seção **Fire TV assets**:

| Campo | Arquivo desta pasta |
|---|---|
| App icon (1280×720) | `icone-fire-tv-1280x720.png` |
| Screenshots (1920×1080, de 3 a 10) | os 5 arquivos da pasta `capturas/` |
| Background image (1920×1080) | `fundo-1920x1080.jpg` |
| Featured content logo (opcional) | `logo-destaque-640x260.png` |
| Featured content background (opcional) | `fundo-destaque-1920x720.jpg` |

Se o formulário também pedir os ícones de tablet ou celular, use `icone-512x512.png` e `icone-114x114.png`, e repita as capturas de TV.

Use **Preview Images on TV** para conferir e clique em **Save**.

## 6. Content Rating
- Violência, conteúdo sexual, linguagem, drogas, álcool, tabaco, apostas, horror: **None** em todos.
- **O app coleta dados pessoais do usuário?** **Não**. Mesmo assim, informe a política de privacidade: `https://contatocapclean-hue.github.io/maazar-play/privacidade.html`
- **Contém anúncios?** Não.
- **Permite compras?** Não.
- **Usuários podem se comunicar ou compartilhar conteúdo entre si?** Não.
- **Compartilha localização?** Não.
- **Direcionado a crianças?** Não.

## 7. APK Files
1. **Apply Amazon DRM?** **No**.
2. Envie o **`Maazar-Play.apk`** (baixe a versão mais recente em Releases).
3. **Device Support** › aba **Amazon Fire TV**: marque todos os aparelhos **Fire TV** que aparecerem como compatíveis. Desmarque *Fire Tablets and Phones* e *Non-Amazon Devices*.
4. **Language support:** Português (e inglês, se quiser).
5. **Export compliance:** marque a confirmação. O app usa apenas conexões HTTPS padrão.
6. **Testing instructions:** copie o texto abaixo:

```
The app has no login and does not provide any content. To test playback:
1. On first launch the "Contas e listas" (Accounts and lists) screen opens.
2. Choose the "Lista M3U" tab, and in "Endereço da lista" enter this public playlist of free-to-air channels (iptv-org project):
   https://iptv-org.github.io/iptv/languages/por.m3u
3. Select "Carregar" (Load). Then open "Canais de TV" (TV channels) in the side menu and select a channel.
Remote: arrows navigate, OK selects, Back goes back (at the home screen it exits the app). CH+/CH- switch channels.
```

## 8. Enviar
Na aba **Review Status**, se não houver pendências, clique em **Submit App**. A revisão costuma levar de 3 a 10 dias úteis.

---

## Avisos importantes
- **Fire TV com Vega OS:** os aparelhos novos com o sistema Vega OS (como o *Fire TV Stick 4K Select*) **não rodam apps Android**. O Maazar Play funciona nos Fire TV com Fire OS, que são a grande maioria (Fire TV Stick, Stick 4K, 4K Max, Cube). Para o Vega OS seria preciso outra versão do app.
- **Fiscalização da Amazon:** a Amazon está bloqueando, junto com a ACE (associação de estúdios), apps ligados a pirataria. Um reprodutor neutro, sem conteúdo e com avisos claros, não é o alvo. Mesmo assim, **o revisor pode pedir esclarecimentos**. Se pedir, responda que o app não contém, não vende e não indica conteúdo, e que o usuário adiciona as próprias listas.
- **Se for recusado:** a Amazon envia o motivo por e-mail. Me mande o texto que eu ajusto o app ou a resposta.
