#!/usr/bin/env bash
# Guarda o relatório (ou uma pasta de fotos) no ramo "relatorio-<nome>" do repositório.
# Uso: relatorio.sh <nome> <arquivo-ou-pasta> <token>
NOME="$1"; ALVO="$2"; TOKEN="$3"
TMP="${RUNNER_TEMP:-/tmp}/rel-$NOME"
rm -rf "$TMP"; mkdir -p "$TMP"
if [ -d "$ALVO" ]; then cp -r "$ALVO"/. "$TMP"/ 2>/dev/null; elif [ -f "$ALVO" ]; then cp "$ALVO" "$TMP/$NOME.log"; else echo "sem relatorio" > "$TMP/$NOME.log"; fi
cd "$TMP" || exit 0
git init -q
git checkout -q -b "relatorio-$NOME"
git add -A
git -c user.name=robo -c user.email=robo@local commit -qm "relatorio $NOME" || exit 0
git push -q -f "https://x-access-token:${TOKEN}@github.com/${GITHUB_REPOSITORY}" "relatorio-$NOME" || true
