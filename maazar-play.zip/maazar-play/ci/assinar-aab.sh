#!/usr/bin/env bash
# Assina o arquivo da Google Play (.aab) com a chave PRIVADA guardada nos Secrets do GitHub.
# Sem os secrets, o .aab continua com a chave de teste (não serve para a Google Play).
# Uso: KS_B64=... KS_PASS=... assinar-aab.sh arquivo.aab
set -e
AAB="$1"
if [ -z "$KS_B64" ] || [ -z "$KS_PASS" ]; then
  echo "AVISO: secrets MAAZAR_KEYSTORE_BASE64 / MAAZAR_KEYSTORE_PASSWORD não configurados; o .aab ficou com a chave de teste."
  exit 0
fi
KS="${RUNNER_TEMP:-/tmp}/upload.keystore"
printf '%s' "$KS_B64" | base64 -d > "$KS"
# remove a assinatura de teste e assina com a chave privada
zip -q -d "$AAB" 'META-INF/*.SF' 'META-INF/*.RSA' 'META-INF/*.EC' 'META-INF/*.DSA' 'META-INF/MANIFEST.MF' > /dev/null 2>&1 || true
jarsigner -sigalg SHA256withRSA -digestalg SHA-256 -keystore "$KS" -storepass "$KS_PASS" -keypass "$KS_PASS" "$AAB" "${KS_ALIAS:-maazar}" > /dev/null
jarsigner -verify -verbose -certs "$AAB" | grep -m1 "CN=" || true
echo "AAB assinado com a chave privada."
rm -f "$KS"
