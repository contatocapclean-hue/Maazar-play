#!/usr/bin/env bash
# Instala o app no emulador, abre, carrega uma lista pública e toca o primeiro canal.
set -x
mkdir -p teste
adb install -r Maazar-Play.apk
adb logcat -c
adb shell am start -n com.maazar.play/.MainActivity
sleep 25
adb exec-out screencap -p > teste/1-abertura.png
adb shell am start -n com.maazar.play/.MainActivity -a android.intent.action.VIEW -d "https://iptv-org.github.io/iptv/languages/por.m3u" --ez maazar_play_first true
sleep 70
adb exec-out screencap -p > teste/2-canal.png
adb shell input keyevent KEYCODE_BACK
sleep 4
adb exec-out screencap -p > teste/3-voltar.png
adb logcat -d > teste/logcat-completo.txt
grep -iE "chromium|console|maazar|AndroidRuntime|FATAL" teste/logcat-completo.txt | tail -500 > teste/logcat.txt
true
