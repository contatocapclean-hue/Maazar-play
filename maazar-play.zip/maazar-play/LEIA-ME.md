# Maazar Play

Reprodutor de listas de canais IPTV (M3U) para:

- **Celular Android**
- **TV com Android TV / Google TV** (Sony, TCL, Philco, Xiaomi, Philips e outras), **TV Box** e **Fire TV Stick**
- **Notebook ou PC com Windows**

Funções:

- **Tela inicial estilo streaming:** destaque grande, "Continuar assistindo", filmes em destaque, séries em alta, canais ao vivo e fileiras por categoria.
- **Menu:** Início, Filmes, Séries, Canais de TV, Esportes e Minha Lista.
- **Conta XC (Xtream Codes):** entre com URL do servidor, usuário e senha. O app carrega canais, filmes e séries da conta, com capas, sinopse, temporadas e episódios. Mostra status e validade da conta.
- **Listas M3U:** por endereço, arquivo ou texto colado. Um link `get.php?username=...&password=...` é reconhecido como conta XC automaticamente.
- Continua filmes e episódios de onde parou e passa para o próximo episódio sozinho.
- Controle remoto completo (setas, OK, Voltar, CH+/CH−, números), favoritos, várias contas salvas, abrir no VLC/MX Player.

---

## Como gerar os aplicativos (grátis, uma vez só)

O GitHub monta o APK e o programa do Windows para você, sem instalar nada no computador.

1. Crie uma conta grátis em **github.com**.
2. Clique em **+** › **New repository**. Dê o nome `maazar-play`, deixe **Public** e clique em **Create repository**.
3. Na página do repositório, clique em **uploading an existing file**.
4. Descompacte o arquivo `maazar-play.zip` no computador e **arraste todo o conteúdo da pasta** (incluindo a pasta `.github`) para a página. Clique em **Commit changes**.
   - No Windows, a pasta `.github` pode ficar oculta. Ative em Explorador de Arquivos › Exibir › Itens ocultos.
5. Abra a aba **Actions**. A tarefa "Gerar aplicativos" começa sozinha e leva uns 10 minutos.
6. Quando terminar (ícone verde), abra **Releases** na lateral direita da página do repositório. Lá estão:
   - `Maazar-Play.apk` — Android (celular e TV)
   - `Maazar-Play-Windows.exe` — Windows

Sempre que você mudar algum arquivo no repositório, uma nova versão é gerada e instala por cima da anterior.

---

## Como instalar

**Celular Android:** abra o link do `.apk` no celular, baixe e toque para instalar. Se aparecer aviso, permita "instalar apps desconhecidos" para o navegador.

**Android TV, Google TV, TV Box, Fire Stick:**
1. Instale o app **Downloader** (da AFTVnews) pela loja da TV.
2. Nas configurações da TV, permita que o Downloader instale apps desconhecidos.
3. No Downloader, digite o link do `Maazar-Play.apk` (copie da página Releases) e instale.
   - Alternativa: copie o `.apk` para um pendrive e abra pelo gerenciador de arquivos da TV.

O app aparece na tela inicial da TV com o banner do Maazar Play.

**Windows:** baixe o `.exe` e abra. Não precisa instalar. Se o Windows mostrar "O Windows protegeu o computador", clique em **Mais informações › Executar assim mesmo** (o aviso aparece porque o programa não tem assinatura paga).

---

## TVs Samsung e LG

Samsung (Tizen) e LG (webOS) usam sistemas próprios que não aceitam APK. Para elas, o caminho mais simples é ligar um **TV Box Android** ou **Fire TV Stick** na TV e instalar o APK nele. Publicar direto nas lojas da Samsung e da LG exige conta de desenvolvedor e aprovação de cada fabricante.

---

## Uso

- Na primeira vez, abre a janela **Contas e listas**. Na aba **Conta XC**, preencha:
  - **URL do servidor:** como o provedor enviou, por exemplo `http://servidor.com:8080`
  - **Usuário** e **Senha**
  - Toque em **Entrar**.
- Na aba **Lista M3U**, adicione uma lista por endereço, arquivo ou texto colado.
- **Controle remoto:** setas navegam e OK abre. Nos canais, OK no canal que está tocando põe em tela cheia; ▲▼ ou CH+/CH− trocam de canal; números vão direto ao canal. Nos filmes e episódios, ◀ ▶ voltam ou avançam 10 segundos e OK pausa. Voltar sempre retorna à tela anterior.
- Conteúdo em formato que o aparelho não toca pode ser aberto no VLC ou MX Player com **Outro app**.

Use apenas contas e listas que você tem direito de assistir.

---

## Estrutura (para quem programa)

| Pasta | O que tem |
|---|---|
| `web/` | O reprodutor (HTML + hls.js + logo). É o mesmo em todas as plataformas. |
| `android/` | App Android em Java (WebView). Abre no Android Studio. |
| `desktop/` | App Windows em Electron. `npm install` e `npm start` para testar. |
| `.github/workflows/` | Gera APK e EXE automaticamente a cada envio. |

A chave de assinatura `android/app/maazar.keystore` (senha `maazar123`) permite que novas versões instalem por cima. Para publicar na Google Play, crie uma chave sua e mantenha em segredo.
