# Maazar Play

Reprodutor para as **listas do próprio usuário**: o endereço de um servidor com usuário e senha, ou o endereço de uma lista M3U. Não tem cadastro, e os dados ficam só no aparelho. O app não traz nenhum conteúdo, e é isso que permite publicá-lo nas lojas.

| Plataforma | Arquivo gerado (em Releases) |
|---|---|
| Celular/tablet Android, Android TV, Google TV, TV Box | `Maazar-Play.apk` (instalação direta, por cima da versão atual; avisa quando há versão nova) |
| Google Play | `Maazar-Play-GooglePlay.aab` |
| Amazon Fire TV (Appstore) | `Maazar-Play-Lojas.apk` (sem atualização própria; a loja cuida disso) |
| TVs LG (webOS) | `Maazar-Play-LG.ipk` |
| TVs Samsung (Tizen) | `Maazar-Play-Samsung-projeto.zip` (assinar no Tizen Studio) |
| Windows / Mac / Linux | `.exe` / `.dmg` / `.AppImage` |
| Site (download, privacidade, termos) | `https://contatocapclean-hue.github.io/maazar-play` |

---

## Versão do app
A versão principal fica no arquivo **`VERSAO`** (ex.: `1.4`). Cada montagem no GitHub vira `1.4.<número da montagem>` em todas as plataformas (Android, TVs LG e Samsung). Para uma mudança grande, aumente para `1.5` e assim por diante, sem nunca diminuir: as lojas não aceitam versão menor que a já enviada.

## Configuração no GitHub (uma vez só)

1. **Site:** em **Settings › Pages** › *Source*, escolha **GitHub Actions**. O site com a política de privacidade e os termos, que as lojas exigem, é publicado sozinho.
2. **E-mail de contato:** o site já mostra `maazarserv@gmail.com`. Para trocar, crie a variável `CONTATO_EMAIL` em **Settings › Secrets and variables › Actions › Variables**.
3. **Chave privada (só para a Google Play):** na aba **Secrets** › *New repository secret*, crie:
   - `MAAZAR_KEYSTORE_BASE64` com o conteúdo de `MAAZAR_KEYSTORE_BASE64.txt`
   - `MAAZAR_KEYSTORE_PASSWORD` com o conteúdo de `MAAZAR_KEYSTORE_PASSWORD.txt`

   Os dois arquivos estão no `chave-privada-maazar.zip`. Guarde uma cópia em local seguro: sem essa chave, não dá para atualizar o app na Google Play. O APK de instalação direta continua com a chave de sempre, então ninguém precisa desinstalar.
4. Troque o `.github/workflows/gerar-apps.yml` pelo novo e envie o novo `maazar-play.zip` (Add file › Upload files). A montagem leva cerca de 15 minutos.

---

## Publicação nas lojas

Os textos, as respostas dos formulários e as imagens estão na pasta `lojas/` (`TEXTOS-DAS-LOJAS.md`).

**Para os revisores**, informe a lista pública de canais abertos do iptv-org (`https://iptv-org.github.io/iptv/languages/por.m3u`). Nunca envie listas com conteúdo pago ou sem licença.

### Google Play (celular e Android TV)
1. Conta de desenvolvedor em **play.google.com/console** (taxa única de US$ 25 e verificação de identidade).
2. *Criar app* › Maazar Play › App › Gratuito. Ative a **Assinatura de apps do Google Play** (a chave privada deste projeto é a *chave de upload*).
3. Envie o `Maazar-Play-GooglePlay.aab`.
4. Preencha a página da loja, a classificação, a segurança dos dados ("não coleta dados"), o acesso ao app e a política de privacidade, usando `lojas/TEXTOS-DAS-LOJAS.md`.
5. Para as TVs: em **Configurações avançadas › Formatos**, adicione **Android TV** e envie o banner e as capturas de TV.
6. Conta pessoal nova: faça antes um **teste fechado com 12 testadores por 14 dias seguidos**.

### Amazon Fire TV
Conta grátis em **developer.amazon.com** › *Add New App › Android*. Envie o `Maazar-Play-Lojas.apk`, marque **Fire TV** e use os mesmos textos e imagens de TV.

> Use o `Maazar-Play-Lojas.apk` na Amazon. O `Maazar-Play.apk` é para instalação direta (Downloader): ele baixa as versões novas sozinho, e as lojas não aceitam isso.

### TVs LG (webOS)
Cadastro no **LG Seller Lounge**. Envie o `Maazar-Play-LG.ipk`, as imagens e o *Self Checklist* com os resultados dos seus testes.

### TVs Samsung (Tizen)
Siga o `LEIA-ME-SAMSUNG.txt` que está dentro do `Maazar-Play-Samsung-projeto.zip`: é preciso assinar no Tizen Studio com um certificado da sua conta Samsung e enviar ao **Samsung TV Seller Office**. Para o Brasil, a Samsung exige conta **Partner Seller** (empresa).

### Ainda não incluídos
- **Roku:** exige reescrever o app na linguagem da Roku.
- **iPhone, iPad e Apple TV:** exigem um Mac e uma conta Apple Developer.

---

## Uso
- **Adicionar lista:** em **Contas e listas**, use a aba **Servidor** (endereço, usuário e senha) ou a aba **Lista M3U** (endereço, arquivo ou texto colado).
- **Controle remoto:** setas navegam, OK abre e Voltar retorna. Nos canais, ▲▼ ou CH+/CH− trocam de canal e os números vão direto ao canal. Nos filmes, ◀ ▶ voltam ou avançam e OK pausa.
- **Ajuste da tela:** margem para TVs que cortam as bordas.

## Estrutura (para quem programa)
| Pasta | O que tem |
|---|---|
| `web/` | O app (HTML + hls.js), igual em todas as plataformas |
| `android/` | App Android (Java, WebView seguro, API 36) |
| `desktop/` | Windows, Mac e Linux (Electron) |
| `tv-lg/`, `tv-samsung/` | Arquivos das TVs LG e Samsung |
| `site/` | Site com download, política de privacidade e termos |
| `ci/` | Scripts da montagem automática |
| `lojas/` | Textos e imagens para as lojas |

A montagem grava relatórios nos ramos `relatorio-*` do repositório. O teste automático no emulador Android abre o app, carrega uma lista pública, toca um canal e salva fotos no ramo `relatorio-teste`.
