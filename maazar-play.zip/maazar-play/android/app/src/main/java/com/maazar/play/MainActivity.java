package com.maazar.play;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int FILE_REQUEST = 41;
    /* O app é servido de um endereço https interno (seguro), em vez de arquivos locais. */
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + APP_HOST + "/assets/index.html";

    private WebView web;
    private FrameLayout root;
    private WebViewAssetLoader assets;
    private ValueCallback<Uri[]> fileCallback;
    private Intent pendingIntent;
    private boolean pageReady = false;
    private boolean immersive = false;
    private Object backCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        assets = new WebViewAssetLoader.Builder()
                .setDomain(APP_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#020A33"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#020A33"));
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        setupInsets();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // Sem acesso a arquivos locais: tudo vem do endereço interno seguro.
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        // Mantém o tamanho do texto igual em todo aparelho.
        s.setTextZoom(100);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (APP_HOST.equals(u.getHost())) return assets.shouldInterceptRequest(u);
                return proxy(request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (APP_HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    toast("Nenhum app consegue abrir este link.");
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (pendingIntent != null) {
                    Intent i = pendingIntent;
                    pendingIntent = null;
                    importFromIntent(i);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Escolher lista M3U"), FILE_REQUEST);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    toast("Este aparelho não tem um gerenciador de arquivos.");
                    return false;
                }
                return true;
            }
        });

        setupBack();

        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();
        pendingIntent = getIntent();
        web.loadUrl(HOME);
    }

    /* ------------------------------------------------------------------
       Conexões com os servidores das listas.
       O próprio app faz o pedido e devolve a resposta à página, liberando o
       acesso (CORS). Listas HLS redirecionadas têm os endereços relativos
       corrigidos para continuar funcionando.
       ------------------------------------------------------------------ */
    private WebResourceResponse proxy(WebResourceRequest req) {
        try {
            if (!"GET".equalsIgnoreCase(req.getMethod())) return null;
            Uri u = req.getUrl();
            String scheme = u.getScheme();
            if (!"http".equals(scheme) && !"https".equals(scheme)) return null;
            Map<String, String> rh = req.getRequestHeaders();
            String accept = header(rh, "Accept");
            if (header(rh, "Range") != null) return null;                       // vídeo direto (filmes)
            if (accept != null && accept.startsWith("image/")) return null;     // capas e logos
            String host = u.getHost() == null ? "" : u.getHost();
            if (host.endsWith(".supabase.co") || host.startsWith("fonts.")) return null;

            String current = u.toString();
            HttpURLConnection c = null;
            int status = 0;
            for (int hop = 0; hop < 6; hop++) {
                c = (HttpURLConnection) new URL(current).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                for (Map.Entry<String, String> h : rh.entrySet()) {
                    String k = h.getKey();
                    if (k == null) continue;
                    String kl = k.toLowerCase(Locale.ROOT);
                    if (kl.equals("origin") || kl.equals("referer") || kl.startsWith("sec-") || kl.equals("x-requested-with")) continue;
                    c.setRequestProperty(k, h.getValue());
                }
                status = c.getResponseCode();
                if (status >= 300 && status < 400 && c.getHeaderField("Location") != null) {
                    current = new URL(new URL(current), c.getHeaderField("Location")).toString();
                    c.disconnect();
                    continue;
                }
                break;
            }
            if (c == null) return null;

            String ctype = c.getContentType();
            String mime = "application/octet-stream", enc = null;
            if (ctype != null) {
                String[] parts = ctype.split(";");
                mime = parts[0].trim();
                for (String p : parts) {
                    String pt = p.trim().toLowerCase(Locale.ROOT);
                    if (pt.startsWith("charset=")) enc = p.trim().substring(8);
                }
            }
            InputStream body = status >= 400 ? c.getErrorStream() : c.getInputStream();
            if (body == null) body = new ByteArrayInputStream(new byte[0]);

            boolean redirected = !current.equals(u.toString());
            boolean isPlaylist = mime.toLowerCase(Locale.ROOT).contains("mpegurl") || current.toLowerCase(Locale.ROOT).contains(".m3u8");
            if (redirected && isPlaylist && status < 400) {
                body = new ByteArrayInputStream(absolutize(readAll(body), current).getBytes("UTF-8"));
                enc = "UTF-8";
            }

            Map<String, String> out = new HashMap<>();
            for (Map.Entry<String, List<String>> h : c.getHeaderFields().entrySet()) {
                String k = h.getKey();
                if (k == null || h.getValue() == null || h.getValue().isEmpty()) continue;
                String kl = k.toLowerCase(Locale.ROOT);
                if (kl.startsWith("access-control-") || kl.equals("content-length") || kl.equals("content-encoding") || kl.equals("transfer-encoding") || kl.equals("set-cookie")) continue;
                out.put(k, h.getValue().get(0));
            }
            out.put("Access-Control-Allow-Origin", "*");
            out.put("Access-Control-Expose-Headers", "*");
            if (status < 100 || (status >= 300 && status < 400)) status = 200;
            String reason = c.getResponseMessage();
            if (reason == null || reason.trim().isEmpty()) reason = status < 400 ? "OK" : "Error";
            return new WebResourceResponse(mime, enc, status, reason, out, body);
        } catch (Exception e) {
            return null;
        }
    }

    private static String header(Map<String, String> h, String name) {
        for (Map.Entry<String, String> e : h.entrySet()) if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) return e.getValue();
        return null;
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    /* Troca endereços relativos de uma lista HLS por endereços completos. */
    static String absolutize(String text, String base) {
        URI b;
        try { b = new URI(base); } catch (Exception e) { return text; }
        StringBuilder sb = new StringBuilder();
        for (String line : text.split("\n", -1)) {
            String t = line.trim();
            if (t.isEmpty()) { sb.append(line).append('\n'); continue; }
            if (t.startsWith("#")) {
                int i = t.indexOf("URI=\"");
                if (i >= 0) {
                    int j = t.indexOf('"', i + 5);
                    if (j > i) {
                        String ref = t.substring(i + 5, j);
                        t = t.substring(0, i + 5) + resolve(b, ref) + t.substring(j);
                    }
                }
                sb.append(t).append('\n');
            } else {
                sb.append(resolve(b, t)).append('\n');
            }
        }
        return sb.toString();
    }

    static String resolve(URI base, String ref) {
        try {
            if (ref.matches("(?i)^[a-z][a-z0-9+.-]*:.*")) return ref;
            return base.resolve(ref).toString();
        } catch (Exception e) {
            return ref;
        }
    }

    /* ------------------------------------------------------------------
       Tela inteira: desde o Android 15 o app ocupa a tela toda; as barras do
       sistema ganham um espaço próprio para não cobrir o conteúdo.
       ------------------------------------------------------------------ */
    private void setupInsets() {
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            @SuppressWarnings("deprecation")
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int l = 0, t = 0, r = 0, b = 0;
                if (!immersive) {
                    if (Build.VERSION.SDK_INT >= 30) {
                        Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                        l = i.left; t = i.top; r = i.right; b = i.bottom;
                    } else {
                        l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                        r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
                    }
                }
                v.setPadding(l, t, r, b);
                return insets;
            }
        });
    }

    /* ------------------------------------------------------------------
       Botão Voltar (controle remoto e celular). A página decide: fecha a
       janela aberta, sai da tela cheia ou volta de tela; senão, fecha o app.
       ------------------------------------------------------------------ */
    private void setupBack() {
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedCallback cb = new OnBackInvokedCallback() {
                @Override
                public void onBackInvoked() {
                    handleBack();
                }
            };
            backCallback = cb;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb);
        }
    }

    private void handleBack() {
        web.evaluateJavascript("(window.maazarBack&&window.maazarBack())?'1':'0'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value == null || !value.contains("1")) finish();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        handleBack();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (pageReady) importFromIntent(intent);
        else pendingIntent = intent;
    }

    /** Abre uma lista .m3u recebida de outro app ("Abrir com Maazar Play"). */
    private void importFromIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction()) || intent.getData() == null) return;
        Uri uri = intent.getData();
        String scheme = uri.getScheme();
        try {
            if ("http".equals(scheme) || "https".equals(scheme)) {
                String js = "window.maazarImportUrl&&window.maazarImportUrl(" + JSONObject.quote(uri.toString()) + ")";
                web.evaluateJavascript(js, null);
                // usado pelo teste automático: depois de carregar a lista, toca o primeiro canal
                if (intent.getBooleanExtra("maazar_play_first", false)) {
                    web.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            web.evaluateJavascript("window.maazarPlayFirst&&window.maazarPlayFirst()", null);
                        }
                    }, 25000);
                }
                return;
            }
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) return;
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            String js = "window.maazarImport&&window.maazarImport(" + JSONObject.quote(fileName(uri)) + "," + JSONObject.quote(sb.toString()) + ")";
            web.evaluateJavascript(js, null);
        } catch (Exception e) {
            toast("Não consegui abrir esta lista.");
        }
    }

    private String fileName(Uri uri) {
        String name = "Lista importada";
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return name;
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /** CH+/CH− e botões de mídia do controle remoto trocam de canal. */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int k = event.getKeyCode();
        boolean up = k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP || k == KeyEvent.KEYCODE_MEDIA_NEXT;
        boolean down = k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN || k == KeyEvent.KEYCODE_MEDIA_PREVIOUS;
        if (up || down) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                web.evaluateJavascript("window.maazarKey&&window.maazarKey('" + (up ? "chup" : "chdown") + "')", null);
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback((OnBackInvokedCallback) backCallback);
        }
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private boolean isTelevision() {
        UiModeManager ui = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        if (ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) return true;
        PackageManager pm = getPackageManager();
        return pm.hasSystemFeature("android.software.leanback")
                || !pm.hasSystemFeature("android.hardware.touchscreen");
    }

    @SuppressWarnings("deprecation")
    private void applyFullscreen(boolean on) {
        immersive = on;
        View decor = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController ctl = getWindow().getInsetsController();
            if (ctl != null) {
                if (on) {
                    ctl.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    ctl.hide(WindowInsets.Type.systemBars());
                } else {
                    ctl.show(WindowInsets.Type.systemBars());
                }
            }
        } else if (on) {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        } else {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
        root.requestApplyInsets();
        if (!isTelevision()) {
            setRequestedOrientation(on ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    /** Funções que a página chama através de window.AndroidBridge. */
    private class Bridge {
        @JavascriptInterface
        public void setFullscreen(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    applyFullscreen(on);
                }
            });
        }

        @JavascriptInterface
        public void openExternal(final String url) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(Uri.parse(url), "video/*");
                    try {
                        startActivity(Intent.createChooser(i, "Abrir com"));
                    } catch (ActivityNotFoundException e) {
                        toast("Instale o VLC ou o MX Player para abrir este conteúdo.");
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean isTV() {
            return isTelevision();
        }

        @JavascriptInterface
        public String deviceName() {
            String m = (Build.MANUFACTURER == null ? "" : Build.MANUFACTURER) + " " + (Build.MODEL == null ? "" : Build.MODEL);
            m = m.trim();
            if (m.isEmpty()) m = "Android";
            return (isTelevision() ? "TV " : "Celular ") + m;
        }
    }
}
